# KONVERTA — profi, magyar videó- és hangkonvertáló

Egy **teljes, reszponzív weboldal + működő Python API**. Nem csupán egy HTML-sablon: a szerver `yt-dlp`-vel kéri le a videókat, az `FFmpeg` végzi a hang-/videófeldolgozást és a külön választható újrakódolást.

## Mit tud?

- **YouTube → MP3 / MP4** és **Videa.hu → MP4** (elsődleges platformok).
- További források: **Vimeo, Dailymotion, TikTok, SoundCloud, Instagram, Facebook, Reddit, X/Twitter, Twitch**. Ezek _best effort_ támogatások; platformonként/videónként változhatnak, bejelentkezést igénylő vagy védett tartalom nem feltétlenül érhető el.
- Egyértelmű **MP3** és **MP4** gombok, minőségválasztás: 128–320 kbps / automatikus–4K (forrásfüggő).
- Külön **Újrakódolás** kapcsoló. Bekapcsolva:
  - hang: **MP3, AAC, Opus** (AAC → `.m4a`; Opus → `.opus`);
  - videó: **H.264/AVC, H.265/HEVC, AV1** (MP4 konténerben);
  - MP4 hangsáv: AAC vagy MP3;
  - sebesség: Gyors / Kiegyensúlyozott / Minőségre optimalizált.
- **300 perc / 5 óra — MINDENHOL.** Minden platformon, formátumban és újrakódolási beállításnál ugyanaz a maximum. A szerver ellenőrzi a videó metaadatait **letöltés előtt**, és a kész fájl hosszát **a végén** is. Ismeretlen időtartamú videót nem enged feldolgozni, mert nem ellenőrizhető a limit.
- **Nincs mesterséges MB- vagy GB-korlát** a programban, de a háttértár, hosting, sávszélesség és forrásoldal tényleges korlátai továbbra is érvényesek.
- Videócím, borítókép és hossz előnézete; folyamatjelző, fájlméret, aktuális letöltési sebesség, becsült hátralévő idő; megszakítás; letöltési gomb; lejárt fájlok automatikus törlése.
- Mobilbarát, teljesen magyar felület, részletes GYIK. Saját felhasználáshoz / privát szerverhez terveztük.

## Egyszerű indítás Windows 11 alatt

1. Telepítsd a **Python 3.11 vagy újabb** verziót a <https://www.python.org/downloads/> címről. A telepítőben jelöld be az **Add Python to PATH** lehetőséget.
2. Telepítsd az **FFmpeg**-et, és gondoskodj róla, hogy az `ffmpeg` és az `ffprobe` parancsok működjenek. Például Windows Terminalból: `winget install Gyan.FFmpeg`; nyiss egy új terminált, majd `ffmpeg -version`.
3. A YouTube teljes támogatásához telepítsd a **Deno 2.x** futtatókörnyezetet: <https://docs.deno.com/runtime/getting_started/installation/>. Ellenőrzés: `deno --version`. Az `yt-dlp[default]` Python-függőség telepíti az EJS segédcsomagot is.
4. Csomagold ki a projektet, és kattints duplán a **`start_windows.bat`** fájlra. Az első indulásnál az alkalmazás telepíti a Python-csomagokat.
5. Nyisd meg a **http://127.0.0.1:8000** oldalt.

Az induláshoz **internetkapcsolat** szükséges az `yt-dlp` telepítéséhez és természetesen a videólinkek lekéréséhez. Az FFmpeg és Deno külön telepítendő.

## Linux / saját VPS

```bash
sudo apt update
sudo apt install -y python3-venv ffmpeg
# A Deno 2.x futtatókörnyezetet is telepítsd a hivatalos útmutató szerint.
./start_linux.sh
# Nyisd meg: http://127.0.0.1:8000
```

## Dockerrel

```bash
docker compose up --build -d
# A szerveren: http://127.0.0.1:8000
```

A Docker-kép a Python 3.12-t, FFmpeg-et, `yt-dlp[default]`-ot és a Deno futtatókörnyezetet készíti elő. Az eredményfájlokat a `konverta_downloads` Docker-volume-ban tárolja. **Éles domainhez** állíts be HTTPS reverse proxyt (például Caddy/Nginx), és vezess be szerveroldali felhasználó-hitelesítést / hozzáférés-védelmet, naplózást, lemez- és forgalomlimiteket. Nem javasolt védtelen, publikus konvertálóként kitenni az internetre: bár nincs fájlméretlimit, a szerver erőforrása és az átvitt adatmennyiség véges.

Megosztott cPanel tárhelyre általában **nem elég** csak a `static` mappát feltölteni. A teljes működéshez olyan Python host szükséges, amely `yt-dlp`-t és FFmpeg-et is tud futtatni; VPS vagy Docker-host a legbiztosabb.

## Fejlesztői parancsok

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

API: `POST /api/info`, `POST /api/convert`, `GET /api/status/{id}`, `POST /api/cancel/{id}`, `GET /api/download/{id}`, `GET /api/health`.

Példa a kódolási lehetőségekkel:

```json
{
  "url": "https://www.youtube.com/watch?v=SAJAT_VIDEO",
  "format": "mp4",
  "quality": 1080,
  "reencode": true,
  "video_codec": "h264",
  "audio_codec": "aac",
  "speed": "fast"
}
```

Minden job külön azonosítót kap. A letöltés indítása HTTP 202 választ ad, és a státuszt külön lehet lekérdezni.

**Beállítható környezeti változók:**

- `CONVERTER_STORAGE`: letöltések könyvtára (alap: `downloads/`)
- `DOWNLOAD_TTL_SECONDS`: kész fájl megőrzési ideje (alap: 21600 s = 6 óra)
- `MAX_ACTIVE_JOBS`: maximális futó/várakozó feladat (alap: 4)
- `CONVERTER_WORKERS`: párhuzamos feldolgozó szál (alap: 2)

**A 300 perces limit nem környezeti változó:** mindenütt kötelezően 18 000 másodperc. **Nincs `MAX_FILE_MB` korlát.**

## Ellenőrzések és tesztek

```bash
python -m pip install pytest httpx
pytest -q
```

A tesztek vizsgálják a pontos 300 perces határt (18 000 s megengedett, afölött elutasítás), platform-/formátumellenőrzést, a biztonságos hostlistát, a végső fájlellenőrzést, továbbá FFmpeg-gel valódi rövid hang- és videókódolást. A tesztek nem igényelnek kapcsolatot a YouTube-pal vagy a Videával.

**Fontos:** a szolgáltatók időről időre változtatnak a lejátszásukon. Ezért a YouTube/Videa élő letöltése *nem garantálható minden videóra*; rendszeresen frissítsd az `yt-dlp` csomagot. A helyi automatikus tesztek nem jelentik azt, hogy külső források élő elérése is ellenőrzött.

## Felhasználási feltételek

Csak a saját tulajdonú, közkinccsé tett vagy más módon jogosan letölthető tartalmakat használd. A forrásoldalak szabályait és a szerzői jogokat be kell tartani. A rendszer nem kerüli meg a DRM-védelmet vagy a jogosultságellenőrzést.
