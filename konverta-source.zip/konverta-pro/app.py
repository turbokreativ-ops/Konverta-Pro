"""Konverta — self-hosted media converter (FastAPI + yt-dlp + FFmpeg).

Use only with media you own or are authorized to download; DRM bypass is not supported.
All supported platforms, audio/video formats and re-encoding paths share a fixed
five-hour source/output duration ceiling (300 minutes).
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

try:
    import yt_dlp
except ImportError:
    yt_dlp = None

ROOT = Path(__file__).resolve().parent
STORAGE = Path(os.environ.get('CONVERTER_STORAGE', str(ROOT / 'downloads'))).resolve()
STORAGE.mkdir(parents=True, exist_ok=True)
MAX_DURATION_SECONDS = 300 * 60  # Applies to EVERY platform and EVERY conversion mode.
# No arbitrary application-level size cap. Disk space, hosting and source limitations apply.
TTL_SECONDS = max(60, int(os.environ.get('DOWNLOAD_TTL_SECONDS', '21600')))
MAX_ACTIVE_JOBS = max(1, int(os.environ.get('MAX_ACTIVE_JOBS', '4')))
WORKERS = max(1, min(4, int(os.environ.get('CONVERTER_WORKERS', '2'))))

SITE_HOSTS = {
    'youtube': {'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be', 'www.youtu.be', 'youtube-nocookie.com', 'www.youtube-nocookie.com'},
    'videa': {'videa.hu', 'www.videa.hu', 'player.videa.hu'},
    'vimeo': {'vimeo.com', 'www.vimeo.com', 'player.vimeo.com'},
    'dailymotion': {'dailymotion.com', 'www.dailymotion.com', 'dai.ly', 'www.dai.ly'},
    'tiktok': {'tiktok.com', 'www.tiktok.com', 'm.tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'},
    'soundcloud': {'soundcloud.com', 'www.soundcloud.com', 'm.soundcloud.com', 'on.soundcloud.com', 'snd.sc'},
    'instagram': {'instagram.com', 'www.instagram.com', 'm.instagram.com'},
    'facebook': {'facebook.com', 'www.facebook.com', 'm.facebook.com', 'web.facebook.com', 'fb.watch', 'www.fb.watch'},
    'reddit': {'reddit.com', 'www.reddit.com', 'old.reddit.com', 'v.redd.it', 'redd.it', 'www.redd.it'},
    'x': {'x.com', 'www.x.com', 'twitter.com', 'www.twitter.com', 'mobile.twitter.com', 't.co'},
    'twitch': {'twitch.tv', 'www.twitch.tv', 'clips.twitch.tv', 'm.twitch.tv'},
}
SITE_FORMATS = {
    site: ('mp4',) if site == 'videa' else ('mp3',) if site == 'soundcloud' else ('mp3', 'mp4')
    for site in SITE_HOSTS
}
VIDEO_ENCODERS = {'h264': 'libx264', 'h265': 'libx265', 'av1': 'libaom-av1'}
VIDEO_SPEEDS = {
    'fast': {'h264': 'veryfast', 'h265': 'fast', 'av1': '6'},
    'balanced': {'h264': 'medium', 'h265': 'medium', 'av1': '5'},
    'quality': {'h264': 'slow', 'h265': 'slow', 'av1': '4'},
}

app = FastAPI(title='Konverta API', docs_url=None, redoc_url=None, openapi_url=None)
executor = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='konverta')
lock = threading.RLock()


@dataclass
class Job:
    id: str
    created: float
    status: str = 'queued'
    percent: int = 0
    message: str = 'Sorba állítva…'
    title: str = ''
    filename: str = ''
    filepath: str = ''
    error: str = ''
    completed_at: float = 0
    downloaded_bytes: int = 0
    total_bytes: int = 0
    speed: float = 0
    eta: int | None = None
    size: int = 0
    cancelled: bool = False
    process: subprocess.Popen | None = field(default=None, repr=False)


jobs: dict[str, Job] = {}
rate_history: dict[str, deque[float]] = defaultdict(deque)


class VideoRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2048)


class ConvertRequest(VideoRequest):
    format: Literal['mp3', 'mp4']
    quality: int
    reencode: bool = False
    audio_codec: Literal['mp3', 'aac', 'opus'] = 'mp3'
    video_codec: Literal['h264', 'h265', 'av1'] = 'h264'
    speed: Literal['fast', 'balanced', 'quality'] = 'fast'


def resolve_site(value: str) -> tuple[str, str]:
    """Allow known public video hosts only; reject credentials, local URLs and ports."""
    value = value.strip()
    try:
        parsed = urlparse(value)
        if (parsed.scheme not in ('http', 'https') or parsed.username or parsed.password
                or parsed.port or not parsed.hostname or '\\' in value or any(ord(c) < 32 for c in value)):
            raise ValueError()
        hostname = parsed.hostname.lower().rstrip('.')
        for site, hosts in SITE_HOSTS.items():
            if hostname in hosts:
                return site, value
    except (ValueError, AttributeError):
        pass
    raise HTTPException(400, 'Nem támogatott link. Használj egy felsorolt videóplatformot.')


def check_input(req: ConvertRequest) -> str:
    site, _ = resolve_site(req.url)
    if req.format not in SITE_FORMATS[site]:
        raise HTTPException(400, 'Ezen a platformon a kiválasztott formátum nem érhető el.')
    if req.format == 'mp3' and req.quality not in (128, 192, 256, 320):
        raise HTTPException(400, 'Hangminőség: 128, 192, 256 vagy 320 kbps.')
    if req.format == 'mp4' and req.quality not in (0, 360, 480, 720, 1080, 1440, 2160):
        raise HTTPException(400, 'Videóminőség: automatikus, 360p, 480p, 720p, 1080p, 1440p vagy 2160p.')
    if req.format == 'mp4' and req.reencode and req.audio_codec not in ('aac', 'mp3'):
        raise HTTPException(400, 'MP4-hez AAC vagy MP3 hangkodek választható.')
    return site


def rate_limit(request: Request, action: str, max_hits: int):
    ip = request.client.host if request.client else 'unknown'
    key, now = f'{ip}:{action}', time.monotonic()
    with lock:
        hits = rate_history[key]
        while hits and now - hits[0] > 60:
            hits.popleft()
        if len(hits) >= max_hits:
            raise HTTPException(429, 'Túl sok kérés. Próbáld újra egy perc múlva.')
        hits.append(now)


def require_tools():
    if yt_dlp is None:
        raise HTTPException(503, 'Telepítsd a yt-dlp csomagot a szerverre.')
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        raise HTTPException(503, 'Az FFmpeg és FFprobe telepítése szükséges.')


def dl_options() -> dict:
    return {
        'quiet': True, 'no_warnings': True, 'noplaylist': True,
        'ignoreconfig': True, 'socket_timeout': 25,
        'retries': 3, 'fragment_retries': 3,
        'extractor_retries': 2, 'ignoreerrors': False,
        'skip_download': True,
    }


def duration_check(seconds: object) -> float:
    if not isinstance(seconds, (float, int)) or isinstance(seconds, bool) or seconds <= 0:
        raise ValueError('A videó időtartama nem állapítható meg, ezért a 300 perces korlát nem ellenőrizhető.')
    if float(seconds) > MAX_DURATION_SECONDS:
        raise ValueError('A videó hosszabb 300 percnél (5 óránál). Ez a limit mindenhol érvényes.')
    return float(seconds)


def read_video_info(url: str) -> dict:
    if yt_dlp is None:
        raise RuntimeError('A yt-dlp nincs telepítve.')
    with yt_dlp.YoutubeDL(dl_options()) as ydl:
        info = ydl.extract_info(url, download=False)
    if not isinstance(info, dict):
        raise ValueError('Nem sikerült lekérni a videót.')
    if info.get('_type') in ('playlist', 'multi_video') or info.get('entries'):
        raise ValueError('Egyetlen videó linkjét add meg, ne lejátszási listát.')
    if info.get('is_live') or info.get('live_status') in ('is_live', 'is_upcoming'):
        raise ValueError('Élő közvetítés nem támogatott.')
    duration_check(info.get('duration'))
    return info


def probe_duration(path: Path) -> float:
    output = subprocess.run(
        ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', str(path)],
        check=True, capture_output=True, text=True, timeout=30,
    )
    data = json.loads(output.stdout)
    return float(data.get('format', {}).get('duration', 0))


def cleanup_jobs() -> None:
    now, folders = time.time(), []
    with lock:
        for key, job in list(jobs.items()):
            if job.status in ('done', 'error', 'cancelled') and job.completed_at and now - job.completed_at > TTL_SECONDS:
                folders.append(STORAGE / job.id)
                jobs.pop(key, None)
    for path in folders:
        shutil.rmtree(path, ignore_errors=True)


def cleanup_loop():
    while True:
        time.sleep(60)
        cleanup_jobs()


threading.Thread(target=cleanup_loop, name='konverta-cleanup', daemon=True).start()


def safe_name(value: str) -> str:
    value = re.sub(r'[^\w\- .()áéíóöőúüűÁÉÍÓÖŐÚÜŰ]', '_', value, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', value).strip(' ._')[:90] or 'konvertalt_video'


def set_status(job: Job, *, status=None, percent=None, message=None, error=None, filepath=None, filename=None, title=None):
    with lock:
        if status is not None:
            job.status = status
            if status in ('done', 'error', 'cancelled'):
                job.completed_at = time.time()
        if percent is not None:
            job.percent = max(job.percent, min(100, int(percent)))
        if message is not None: job.message = message
        if error is not None: job.error = error
        if filepath is not None: job.filepath = filepath
        if filename is not None: job.filename = filename
        if title is not None: job.title = title


def public_error(exc: Exception) -> str:
    value = str(exc).splitlines()[-1][:280]
    value = re.sub(r'https?://\S+', '[link]', value)
    value = value.replace(str(ROOT), '[szerver]').replace(str(STORAGE), '[tárhely]')
    return value or 'Nem sikerült feldolgozni. Próbálj másik videót.'


def find_download(folder: Path, extension: str | None = None) -> Path:
    skip = ('.part', '.ytdl', '.json', '.temp')
    candidates = [p for p in folder.iterdir() if p.is_file() and p.name.startswith('media.')
                  and not p.name.endswith(skip)]
    if extension:
        candidates = [p for p in candidates if p.suffix.lower() == extension]
    if not candidates:
        raise FileNotFoundError('A letöltött médiafájl nem található.')
    return max(candidates, key=lambda p: p.stat().st_size)


def ffmpeg_encode(job: Job, source: Path, target: Path, req: ConvertRequest, duration: float):
    """Run user-selected codecs and update real encoding progress, with cancellation."""
    base = ['ffmpeg', '-hide_banner', '-nostdin', '-loglevel', 'error', '-y', '-i', str(source)]
    if req.format == 'mp3':
        codec = req.audio_codec if req.reencode else 'mp3'
        encoder = {'mp3': 'libmp3lame', 'aac': 'aac', 'opus': 'libopus'}[codec]
        base += ['-vn', '-map', '0:a:0', '-c:a', encoder, '-b:a', f'{req.quality}k']
    else:
        video_codec = req.video_codec
        encoder = VIDEO_ENCODERS[video_codec]
        base += ['-map', '0:v:0', '-map', '0:a:0?', '-c:v', encoder]
        preset = VIDEO_SPEEDS[req.speed][video_codec]
        if video_codec == 'av1':
            base += ['-cpu-used', preset, '-crf', '32', '-b:v', '0']
        else:
            base += ['-preset', preset, '-crf', '23' if video_codec == 'h264' else '27']
        base += ['-pix_fmt', 'yuv420p']
        if video_codec == 'h265':
            base += ['-tag:v', 'hvc1']
        audio_encoder = {'aac': 'aac', 'mp3': 'libmp3lame'}[req.audio_codec]
        base += ['-c:a', audio_encoder, '-b:a', '192k', '-movflags', '+faststart']
    base += ['-progress', 'pipe:1', '-nostats', str(target)]
    process = subprocess.Popen(base, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               stdin=subprocess.DEVNULL, text=True, bufsize=1)
    with lock:
        job.process = process
    try:
        assert process.stdout is not None
        for line in process.stdout:
            if job.cancelled:
                process.terminate()
                raise InterruptedError('Megszakítva.')
            if '=' not in line:
                continue
            key, value = line.strip().split('=', 1)
            if key in ('out_time_ms', 'out_time_us') and value.isdigit():
                fraction = min(1.0, int(value) / 1_000_000 / max(duration, 1.0))
                set_status(job, percent=85 + int(fraction * 13), message='Újrakódolás folyamatban…')
        code = process.wait(timeout=30)
        if job.cancelled:
            raise InterruptedError('Megszakítva.')
        if code != 0:
            stderr = process.stderr.read()[-600:] if process.stderr else ''
            raise RuntimeError('Az FFmpeg újrakódolás sikertelen: ' + stderr.strip())
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        with lock:
            job.process = None
        if process.stdout: process.stdout.close()
        if process.stderr: process.stderr.close()


def convert_worker(job: Job, req: ConvertRequest):
    folder = STORAGE / job.id
    folder.mkdir(parents=True, exist_ok=True)
    try:
        if job.cancelled:
            raise InterruptedError('Megszakítva.')
        set_status(job, status='working', percent=2, message='Videó ellenőrzése…')
        info = read_video_info(req.url)
        duration = duration_check(info.get('duration'))
        if job.cancelled:
            raise InterruptedError('Megszakítva.')
        set_status(job, title=str(info.get('title') or 'Videó')[:160], percent=8,
                   message='Letöltés előkészítése…')

        def hook(p):
            if job.cancelled:
                raise InterruptedError('Megszakítva.')
            if p.get('status') == 'downloading':
                total = p.get('total_bytes') or p.get('total_bytes_estimate') or 0
                downloaded = p.get('downloaded_bytes') or 0
                with lock:
                    job.downloaded_bytes = int(downloaded)
                    job.total_bytes = int(total)
                    job.speed = float(p.get('speed') or 0)
                    job.eta = p.get('eta')
                fraction = downloaded / total if total else 0.08
                set_status(job, percent=10 + int(min(1, fraction) * 72), message='Videó letöltése…')
            elif p.get('status') == 'finished':
                set_status(job, percent=83, message='Letöltés befejezve, fájl feldolgozása…')

        opts = dl_options()
        opts.update({
            'skip_download': False,
            'outtmpl': str(folder / 'media.%(ext)s'),
            'progress_hooks': [hook],
            'overwrites': True,
        })
        if req.format == 'mp3':
            opts['format'] = 'bestaudio/best'
        elif req.reencode:
            maxh = f'[height<={req.quality}]' if req.quality else ''
            opts.update({
                'format': f'bv*{maxh}+ba/b{maxh}/best',
                'merge_output_format': 'mkv',
            })
        else:
            maxh = f'[height<={req.quality}]' if req.quality else ''
            opts.update({
                'format': (
                    f'bv[vcodec^=avc1][ext=mp4]{maxh}+ba[ext=m4a]/'
                    f'bv[ext=mp4]{maxh}+ba[ext=m4a]/'
                    f'b[ext=mp4]{maxh}/'
                    f'bv*{maxh}+ba/b{maxh}/best'
                ),
                'merge_output_format': 'mp4',
                'postprocessors': [{'key': 'FFmpegVideoRemuxer', 'preferedformat': 'mp4'}],
            })
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([req.url])
        if job.cancelled:
            raise InterruptedError('Megszakítva.')

        if req.format == 'mp4' and not req.reencode:
            source = find_download(folder, '.mp4')
            target = source
        else:
            source = find_download(folder)
            if req.format == 'mp3':
                suffix = {'mp3': '.mp3', 'aac': '.m4a', 'opus': '.opus'}[
                    req.audio_codec if req.reencode else 'mp3']
            else:
                suffix = '.mp4'
            target = folder / ('output' + suffix)
            set_status(job, percent=85, message='Újrakódolás folyamatban…' if req.reencode else 'MP3 elkészítése…')
            ffmpeg_encode(job, source, target, req, duration)
            if source != target:
                source.unlink(missing_ok=True)
        if not target.is_file() or target.stat().st_size == 0:
            raise RuntimeError('A kimeneti fájl nem készült el.')
        # Validate the RESULT, not just metadata. 0.5 sec tolerance for encoder/container rounding.
        output_duration = probe_duration(target)
        if output_duration > MAX_DURATION_SECONDS + 0.5:
            raise ValueError('A kimeneti fájl 300 percnél hosszabb. Nem adható ki.')
        if output_duration <= 0:
            raise ValueError('A kész fájl hossza nem ellenőrizhető.')
        if job.cancelled:
            raise InterruptedError('Megszakítva.')
        with lock:
            job.size = target.stat().st_size
        set_status(job, status='done', percent=100, message='Elkészült!',
                   filepath=str(target), filename=f'{safe_name(job.title)}{target.suffix}')
    except InterruptedError:
        set_status(job, status='cancelled', message='A konvertálás megszakítva.')
        shutil.rmtree(folder, ignore_errors=True)
    except Exception as exc:
        if job.cancelled:
            set_status(job, status='cancelled', message='A konvertálás megszakítva.')
        else:
            set_status(job, status='error', message='Sikertelen átalakítás', error=public_error(exc))
        shutil.rmtree(folder, ignore_errors=True)


@app.get('/api/health')
def health():
    return {
        'ok': True,
        'ready': yt_dlp is not None and bool(shutil.which('ffmpeg')) and bool(shutil.which('ffprobe')),
        'yt_dlp': yt_dlp is not None,
        'ffmpeg': bool(shutil.which('ffmpeg')),
        'javascript': bool(shutil.which('deno') or shutil.which('node') or shutil.which('bun')),
        'max_duration_seconds': MAX_DURATION_SECONDS,
        'max_file_mb': None,
        'platforms': list(SITE_HOSTS),
    }


@app.post('/api/info')
def info(req: VideoRequest, request: Request):
    rate_limit(request, 'info', 24)
    site, url = resolve_site(req.url)
    require_tools()
    try:
        data = read_video_info(url)
    except Exception as exc:
        raise HTTPException(422, public_error(exc)) from None
    return {
        'site': site,
        'title': str(data.get('title') or 'Ismeretlen videó')[:180],
        'duration': data.get('duration'),
        'thumbnail': data.get('thumbnail') or '',
        'uploader': str(data.get('uploader') or '')[:100],
        'formats': SITE_FORMATS[site],
        'max_duration_seconds': MAX_DURATION_SECONDS,
    }


@app.post('/api/convert', status_code=202)
def convert(req: ConvertRequest, request: Request):
    rate_limit(request, 'convert', 8)
    check_input(req)
    require_tools()
    cleanup_jobs()
    with lock:
        active = sum(1 for j in jobs.values() if j.status in ('queued', 'working'))
        if active >= MAX_ACTIVE_JOBS:
            raise HTTPException(429, 'A szerver most elfoglalt. Próbáld újra később.')
        job = Job(id=uuid.uuid4().hex, created=time.time())
        jobs[job.id] = job
    executor.submit(convert_worker, job, req)
    return {'id': job.id, 'status': job.status}


@app.get('/api/status/{job_id}')
def status(job_id: str):
    cleanup_jobs()
    with lock:
        job = jobs.get(job_id)
        if not job:
            raise HTTPException(404, 'A feladat nem található vagy lejárt.')
        return {
            'id': job.id, 'status': job.status, 'percent': job.percent,
            'message': job.message, 'title': job.title, 'error': job.error,
            'filename': job.filename, 'bytes': job.downloaded_bytes,
            'total_bytes': job.total_bytes, 'speed': job.speed, 'eta': job.eta,
            'size': job.size,
            'download': f'/api/download/{job.id}' if job.status == 'done' else None,
        }


@app.get('/api/download/{job_id}')
def download(job_id: str):
    cleanup_jobs()
    with lock:
        job = jobs.get(job_id)
        if not job or job.status != 'done' or not job.filepath:
            raise HTTPException(404, 'A fájl nem érhető el.')
        path, filename = Path(job.filepath), job.filename
    if not path.is_file():
        raise HTTPException(404, 'A fájl már nincs a szerveren.')
    with lock:
        job.completed_at = time.time()
    media = {'.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.opus': 'audio/ogg', '.mp4': 'video/mp4'}
    return FileResponse(path, media_type=media.get(path.suffix, 'application/octet-stream'), filename=filename)


@app.post('/api/cancel/{job_id}')
def cancel(job_id: str):
    with lock:
        job = jobs.get(job_id)
        if not job:
            raise HTTPException(404, 'A feladat nem található vagy lejárt.')
        if job.status in ('done', 'error', 'cancelled'):
            return {'status': job.status}
        job.cancelled = True
        proc = job.process
        if job.status == 'queued':
            set_status(job, status='cancelled', message='A konvertálás megszakítva.')
    if proc is not None and proc.poll() is None:
        proc.terminate()
    return {'status': 'cancelling'}


app.mount('/', StaticFiles(directory=ROOT / 'static', html=True), name='static')
