(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const els = {
    form: $('convertForm'), url: $('videoUrl'), note: $('siteNote'), paste: $('pasteBtn'), inspect: $('inspectBtn'),
    mp3: $('mp3Tab'), mp4: $('mp4Tab'), quality: $('quality'),
    reencode: $('reencodeToggle'), panel: $('reencodePanel'), videoCodec: $('videoCodec'),
    videoField: $('videoCodecField'), audioCodec: $('audioCodec'), speed: $('speedPreset'), codecHint: $('codecHint'),
    submit: $('convertBtn'), submitText: $('convertBtnText'),
    preview: $('preview'), previewImg: $('previewImg'), previewTitle: $('previewTitle'), previewDetails: $('previewDetails'),
    box: $('statusBox'), icon: $('statusIcon'), label: $('statusLabel'), percent: $('statusPercent'),
    detail: $('statusDetail'), fill: $('progressFill'), download: $('downloadLink'),
    downloadText: $('downloadText'), cancel: $('cancelBtn'), metrics: $('statusMetrics'),
    size: $('statusSize'), speedOut: $('statusSpeed'), eta: $('statusEta'),
  };
  const HOSTS = {
    youtube: ['youtube.com','www.youtube.com','m.youtube.com','music.youtube.com','youtu.be','www.youtu.be','youtube-nocookie.com','www.youtube-nocookie.com'],
    videa: ['videa.hu','www.videa.hu','player.videa.hu'],
    vimeo: ['vimeo.com','www.vimeo.com','player.vimeo.com'],
    dailymotion: ['dailymotion.com','www.dailymotion.com','dai.ly','www.dai.ly'],
    tiktok: ['tiktok.com','www.tiktok.com','m.tiktok.com','vm.tiktok.com','vt.tiktok.com'],
    soundcloud: ['soundcloud.com','www.soundcloud.com','m.soundcloud.com','on.soundcloud.com','snd.sc'],
    instagram: ['instagram.com','www.instagram.com','m.instagram.com'],
    facebook: ['facebook.com','www.facebook.com','m.facebook.com','web.facebook.com','fb.watch','www.fb.watch'],
    reddit: ['reddit.com','www.reddit.com','old.reddit.com','v.redd.it','redd.it','www.redd.it'],
    x: ['x.com','www.x.com','twitter.com','www.twitter.com','mobile.twitter.com','t.co'],
    twitch: ['twitch.tv','www.twitch.tv','clips.twitch.tv','m.twitch.tv'],
  };
  const SITE_NAMES = {youtube:'YouTube',videa:'Videa.hu',vimeo:'Vimeo',dailymotion:'Dailymotion',tiktok:'TikTok',soundcloud:'SoundCloud',instagram:'Instagram',facebook:'Facebook',reddit:'Reddit',x:'X / Twitter',twitch:'Twitch'};
  const qualityOptions = {
    mp3: [[128,'128 kbps · Standard'],[192,'192 kbps · Jó minőség'],[256,'256 kbps · Kiváló'],[320,'320 kbps · Maximum']],
    mp4: [[0,'Automatikus · Legjobb'],[360,'360p · Kis fájl'],[480,'480p · SD'],[720,'720p · HD'],[1080,'1080p · Full HD'],[1440,'1440p · 2K'],[2160,'2160p · 4K']],
  };
  let format = 'mp3';
  let activeJob = null;
  let timer = null;
  let infoNonce = 0;
  let inspectedUrl = '';
  let running = false;

  function siteOf(url) {
    try {
      const parsed = new URL(url.trim());
      if (!['http:','https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.port) return null;
      for (const [name, hosts] of Object.entries(HOSTS)) if (hosts.includes(parsed.hostname.toLowerCase())) return name;
    } catch (_) { /* Link is incomplete. */ }
    return null;
  }
  function note(text, error = false) { els.note.textContent = text; els.note.classList.toggle('error', error); }
  function formatTime(seconds) {
    const s = Math.max(0, Math.floor(Number(seconds) || 0));
    return s >= 3600 ? `${Math.floor(s/3600)}:${String(Math.floor((s%3600)/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}` : `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
  }
  function bytes(n) { const x = Number(n)||0; return x >= 1073741824 ? `${(x/1073741824).toFixed(2)} GB` : x >= 1048576 ? `${(x/1048576).toFixed(1)} MB` : `${(x/1024).toFixed(0)} KB`; }
  function setFormat(next) {
    const previousFormat = format;
    const site = siteOf(els.url.value);
    if (site === 'videa') next = 'mp4';
    if (site === 'soundcloud') next = 'mp3';
    format = next;
    els.mp3.disabled = site === 'videa';
    els.mp4.disabled = site === 'soundcloud';
    els.mp3.classList.toggle('selected', format === 'mp3');
    els.mp4.classList.toggle('selected', format === 'mp4');
    els.mp3.setAttribute('aria-pressed', String(format === 'mp3'));
    els.mp4.setAttribute('aria-pressed', String(format === 'mp4'));
    const prev = Number(els.quality.value);
    els.quality.replaceChildren(...qualityOptions[format].map(([value, label]) => new Option(label, value)));
    els.quality.value = qualityOptions[format].some(([value]) => value === prev) ? String(prev) : (format === 'mp3' ? '192' : '1080');
    updateAdvanced(previousFormat !== format);
  }
  function updateAdvanced(formatChanged = false) {
    const enabled = els.reencode.checked;
    els.panel.classList.toggle('hidden', !enabled);
    els.reencode.setAttribute('aria-expanded', String(enabled));
    els.videoField.classList.toggle('hidden', format === 'mp3');
    const previous = els.audioCodec.value;
    const codecs = format === 'mp4' ? [['aac','AAC · Javasolt'],['mp3','MP3 · Alternatív']] : [['mp3','MP3 · Legelterjedtebb'],['aac','AAC · .m4a fájl'],['opus','Opus · .opus fájl']];
    els.audioCodec.replaceChildren(...codecs.map(([v,label]) => new Option(label, v)));
    els.audioCodec.value = !formatChanged && codecs.some(([v]) => v === previous) ? previous : (format === 'mp4' ? 'aac' : 'mp3');
    updateHint();
  }
  function updateHint() {
    if (format === 'mp4') {
      const videoDesc = {h264:'széles kompatibilitás',h265:'jobb tömörítés, hosszabb feldolgozás',av1:'modern kodek, számításigényes'};
      els.codecHint.textContent = `MP4 · ${els.videoCodec.value.toUpperCase()} (${videoDesc[els.videoCodec.value]}). Hang: ${els.audioCodec.value.toUpperCase()}. Az újrakódolás több időt igényelhet.`;
    } else {
      els.codecHint.textContent = els.audioCodec.value === 'aac' ? 'AAC esetén a kész hangfájl .m4a lesz.' : els.audioCodec.value === 'opus' ? 'Opus esetén a kész hangfájl .opus lesz.' : 'MP3 esetén a kész hangfájl .mp3 lesz.';
    }
  }
  function displayPreview(data) {
    els.previewTitle.textContent = data.title || 'Ismeretlen videó';
    els.previewDetails.textContent = [SITE_NAMES[data.site], data.uploader, data.duration ? formatTime(data.duration) : ''].filter(Boolean).join(' · ');
    if (data.thumbnail && /^https?:\/\//i.test(data.thumbnail)) { els.previewImg.src = data.thumbnail; els.previewImg.style.display = 'block'; }
    else { els.previewImg.removeAttribute('src'); els.previewImg.style.display = 'none'; }
    els.preview.classList.remove('hidden');
    note(`Videó ellenőrizve · ${formatTime(data.duration)} / 5:00:00 maximum`);
  }
  async function inspectUrl() {
    const url = els.url.value.trim(), site = siteOf(url);
    if (!site) { els.preview.classList.add('hidden'); inspectedUrl = ''; note(url ? 'Érvényes, támogatott videólinket adj meg.' : 'Elsőként YouTube és Videa, továbbá több ismert oldal.', Boolean(url)); return; }
    setFormat(format);
    if (inspectedUrl === url) return;
    inspectedUrl = url;
    const nonce = ++infoNonce;
    note(`${SITE_NAMES[site]} felismerve · Videó ellenőrzése…`);
    try {
      const response = await fetch('/api/info', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url})});
      const data = await response.json();
      if (nonce !== infoNonce || url !== els.url.value.trim()) return;
      if (response.ok) displayPreview(data);
      else {els.preview.classList.add('hidden'); note(typeof data.detail === 'string' ? data.detail : 'A videó nem ellenőrizhető.',true);}
    } catch (_) {if (nonce === infoNonce) {els.preview.classList.add('hidden'); note('A szerver nem elérhető. Indítsd el az alkalmazást.',true);}}
  }
  function updateStatus(data) {
    els.box.classList.remove('hidden');
    const failed = data.status === 'error', cancelled = data.status === 'cancelled', done = data.status === 'done';
    const finished = failed || done || cancelled;
    els.icon.className = `spinner${done ? ' complete' : failed || cancelled ? ' failed' : ''}`;
    els.label.textContent = done ? 'Sikeres konvertálás' : failed ? 'Hiba történt' : cancelled ? 'Konvertálás megszakítva' : data.message || 'Folyamatban…';
    els.percent.textContent = `${Math.round(data.percent || 0)}%`;
    els.fill.style.width = `${data.percent || 0}%`;
    els.detail.textContent = failed ? data.error || 'A feldolgozás sikertelen.' : cancelled ? 'A műveletet megszakítottad.' : done ? `A fájl elkészült: ${data.filename || ''}` : data.title || 'A feldolgozás a szerver sebességétől függ.';
    els.download.classList.toggle('hidden', !done);
    if (done && data.download) {els.download.href = data.download; els.downloadText.textContent = `Letöltés (${bytes(data.size)})`;}
    els.cancel.classList.toggle('hidden', finished || !activeJob);
    els.metrics.classList.toggle('hidden', !(data.bytes > 0 && !finished));
    els.size.textContent = data.total_bytes ? `${bytes(data.bytes)} / ${bytes(data.total_bytes)}` : bytes(data.bytes);
    els.speedOut.textContent = data.speed ? `${bytes(data.speed)}/s` : '';
    els.eta.textContent = Number.isFinite(data.eta) && data.eta >= 0 ? `Kb. ${formatTime(data.eta)} hátra` : '';
    if (finished) {
      clearInterval(timer); timer = null;
      running = false;
      els.submit.disabled = false;
      els.submitText.textContent = 'Új konvertálás indítása';
    }
  }
  async function poll() {
    if (!activeJob) return;
    try {
      const response = await fetch(`/api/status/${activeJob}`);
      const data = await response.json();
      if (!response.ok) throw Error(typeof data.detail === 'string' ? data.detail : 'A feladat nem található.');
      updateStatus(data);
    } catch (error) {updateStatus({status:'error',error:error.message,percent:0});}
  }
  els.url.addEventListener('input', () => {
    ++infoNonce; inspectedUrl = ''; els.preview.classList.add('hidden');
    const site = siteOf(els.url.value);
    setFormat(format);
    note(site ? `${SITE_NAMES[site]} felismerve · A linket ellenőrizheted vagy indíthatod a konvertálást.` : 'Támogatott: YouTube, Videa, Vimeo, Dailymotion, TikTok és továbbiak.');
  });
  els.url.addEventListener('blur', () => {if (els.url.value.trim()) inspectUrl();});
  els.inspect.addEventListener('click', inspectUrl);
  els.mp3.addEventListener('click', () => setFormat('mp3'));
  els.mp4.addEventListener('click', () => setFormat('mp4'));
  els.reencode.addEventListener('change', updateAdvanced);
  els.videoCodec.addEventListener('change', updateHint);
  els.audioCodec.addEventListener('change', updateHint);
  els.paste.addEventListener('click', async () => {
    try {els.url.value = await navigator.clipboard.readText(); els.url.dispatchEvent(new Event('input')); inspectUrl();}
    catch (_) {note('A vágólap nem elérhető. Illeszd be a linket kézzel.',true); els.url.focus();}
  });
  els.cancel.addEventListener('click', async () => {
    if (!activeJob) return;
    els.cancel.disabled = true;
    try { await fetch(`/api/cancel/${activeJob}`, {method:'POST'}); await poll(); }
    finally {els.cancel.disabled = false;}
  });
  els.form.addEventListener('submit', async e => {
    e.preventDefault();
    if (running) return;
    const url = els.url.value.trim();
    if (!siteOf(url)) {note('Adj meg érvényes videólinket.',true); els.url.focus(); return;}
    if (timer) clearInterval(timer);
    activeJob = null;
    running = true;
    els.submit.disabled = true;
    els.submitText.textContent = 'Konvertálás folyamatban…';
    updateStatus({status:'queued',message:'Kérés elküldése…',percent:0});
    els.submit.disabled = true;
    try {
      const response = await fetch('/api/convert', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({url,format,quality:Number(els.quality.value),reencode:els.reencode.checked,
          audio_codec:els.reencode.checked ? els.audioCodec.value : (format === 'mp4' ? 'aac':'mp3'),
          video_codec:els.videoCodec.value,speed:els.speed.value}),
      });
      const data = await response.json();
      if (!response.ok) throw Error(typeof data.detail === 'string' ? data.detail : 'A kérést nem sikerült elküldeni.');
      activeJob = data.id;
      await poll();
      if (running && timer === null) timer = setInterval(poll, 1200);
    } catch (error) {updateStatus({status:'error',error:error.message,percent:0});}
  });
  setFormat('mp3');
})();
